import "./NotFound.css";

const NotFound = () => {
  return <main>NotFound</main>;
};

export default NotFound;

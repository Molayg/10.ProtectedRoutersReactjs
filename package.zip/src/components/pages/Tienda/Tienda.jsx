import React from "react";
import "./Tienda.css";

const Tienda = () => {
  return (
    <main>
      <h1>TIENDA</h1>
      <p>Puedes contactar 677778918.</p>
    </main>
  );
};

export default Tienda;

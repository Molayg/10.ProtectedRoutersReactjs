import React from "react";
import "./Reserva.css";

const Reserva = () => {
  return (
    <main>
      <h1>RESERVA TU CITA</h1>
      <p>Puedes solicitar tu cita teléfonica al 677778918.</p>
    </main>
  );
};

export default Reserva;

import React from "react";
import "./Servicios.css";

const Servicios = () => {
  return (
    <main>
      <h1>SERVICIOS</h1>
      <p>Los servicios que presta JIMMY´S BARBERSHOP son:</p>

      <nav>
        <ul>
          <li>Lavar, cortar y secar el pelo. </li>
          <li>Peinar.</li>
          <li>Realizar la permanente.</li>
          <li>Alisar el pelo.</li>
          <li>Teñir el pelo.</li>
          <li>Asesoramiento sobre productos de peluquería.</li>
        </ul>
      </nav>
    </main>
  );
};

export default Servicios;

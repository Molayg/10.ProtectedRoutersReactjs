import React from "react";
import "./Footer.css";

const Footer = () => {
  return (
    <footer>
      <p>JIMMY´S BARBERIA 2023</p>
    </footer>
  );
};

export default Footer;
